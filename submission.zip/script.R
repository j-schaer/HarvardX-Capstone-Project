# R script for the 'Choose Your Own' project
# as part of the HarvardX Professional Certificate in Data Science

# Author: Julien Schaer
# Date: 10/16/2020





##########################################################
# 1. Introduction
##########################################################


# The aim of this report is to present the various data analysis and machine learning tasks performed on
# the basis of the “Austin Animal Center Shelter Intakes and Outcomes” dataset, as part of the HarvardX
# curriculum in data science.

# The dataset in question is publicly available on the Kaggle platform, at
# https://www.kaggle.com/aaronschlegel/austin-animal-center-shelter-intakes-and-outcomes?select=aac_intakes_outcomes.csv .
# A copy of this dataset is also available in the submission folder of the GitHub repository
# created for this project (https://github.com/j-schaer/HarvardX-Capstone-Project/blob/main/submission.zip).
# In this respect, the R script and Rmd report submitted alongside the present document both make use
# of a relative path to load this dataset, and this relative path reflects the structure of the
# submission folder uploaded to the GitHub repository.

# The main task undertaken in this report is to develop machine learning models aimed at predicting the
# fate of an animal (outcome) on the basis of information available upon its intake into the shelter,
# such as animal type, sex, age, etc. More precisely, the outcome will be deemed a “success” (1) if the
# animal is returned to its owner or adopted, and a “non-success” (0) in other cases (e.g. the animal
# died or went missing). In this regard, a detailed description of the variables contained in this
# dataset can be found in chapter 2 (Data Wrangling). It has been decided to describe these variables
# in chapter 2 rather than in the Introduction (chapter 1), as this description is of direct relevance
# to data wrangling tasks (e.g. variable selection).

# From a theoretical perspective, this machine learning project falls within the scope of classification
# problems, whereby it is attempted to predict the class of an object on the basis of a range of
# predictors. Classification problems have been introduced in the “Machine Learning” course of the
# HarvardX curriculum, by means of case studies on the Titanic (survived v. died), digit recognition
# (7 v. 2), and breast cancer (malignant v. benign tumors). In the case at hand, the “outcome”
# associated with each observation is therefore to be interpreted as consisting of two classes,
# “success” (1) and “non-success” (0).

# This report consists of six main chapters: Introduction (1), Data Wrangling (2), Data Exploration and
# Visualization (3), Modeling Approach (4), Results (5) and Conclusion (6).

# Chapter 2 (Data Wrangling) consists of two sections, Data Cleaning (2.1) and Data Partition (2.2).
# The first section performs some preliminary wrangling on the raw dataset in order to adjust it to the
# goal of this project. The second section performs a partition of this dataset into a training set, a
# testing set and a hold-out set (the latter being used only for the test of our best-performing model).

# Chapter 3 (Data Exploration and Visualization) consists of nine sections, with each section exploring
# the relationship between the outcome variable (success v. non-success) and a predictor variable.

# Chapter 4 (Modeling Approach) consists of seven sections. The first section (4.1) gives an
# overview of the modeling approach of this report and introduces the various machine learning
# models deployed in the next five sections (4.2 to 4.6) – namely a baseline model, followed by
# logistic regression, knn, classification tree and random forest. The last section (4.7) tests
# the best-performing model on the basis of the hold-out set.

# Chapter 5 (Results) discusses the performance of the five machine learning models used in the
# previous chapter.

# Chapter 6 (Conclusion) gives a brief summary of the present report, discusses its limitations and
# offers suggestions for future work.





##########################################################
# 2. Data Wrangling
##########################################################


# Chapter 2 consists of two sections, Data Cleaning (2.1) and Data Partition (2.2). The first section
# performs some preliminary wrangling on the raw dataset in order to adjust it to the goal of this
# project. The second section performs a partition of this dataset into a training set, a testing set
# and a hold-out set (the latter being used only for the test of our best-performing model).





##########################################################
# 2.1 Data Cleaning
##########################################################


# The first task performed in this section consists of loading the raw dataset and installing all the
# required packages.
# In order to comply with the instructions given in the HarvardX grading rubric, the dataset is loaded
# using a relative path, and missing packages are automatically installed.

# load the dataset, using a relative path
df <- read.csv("./aac_intakes_outcomes.csv")

# automatically install missing packages
if(!require(tidyverse)) install.packages("tidyverse", repos = "http://cran.us.r-project.org")
if(!require(lubridate)) install.packages("lubridate", repos = "http://cran.us.r-project.org")
if(!require(caret)) install.packages("caret", repos = "http://cran.us.r-project.org")
if(!require(rpart.plot)) install.packages("rpart.plot", repos = "http://cran.us.r-project.org")

# load required packages
library(tidyverse)
library(lubridate)
library(caret)
library(rpart.plot)





# Having successfully loaded the dataset, we can move on to variable selection. The goal is to select
# only the variables that are useful to our project, i.e. those variables that can help us predict
# outcome on the basis of intake information.
# Let us first take a look at the list of variables. There is a total of 41 variables in the raw
# dataset.

names(df)





# As we are only interested in the type of outcome (fifth column), we drop all other outcome-related
# variables. For instance, age upon outcome is not relevant to our machine learning project (what will
# be relevant is age upon intake).

df <- df %>%
  select(-c("age_upon_outcome", "animal_id_outcome", "outcome_subtype", "sex_upon_outcome",
            "age_upon_outcome_.days.", "age_upon_outcome_.years.", "age_upon_outcome_age_group",
            "outcome_datetime", "outcome_month", "outcome_year", "outcome_monthyear", "outcome_weekday",
            "outcome_hour", "outcome_number"))





# We also drop variables that do not provide direct information on intake. For instance, date of birth
# is not relevant to this project, while age upon intake is relevant.

df <- df %>%
  select(-c("date_of_birth", "dob_year", "dob_month", "dob_monthyear", "time_in_shelter",
            "time_in_shelter_days"))





# All remaining variables are related to intake, but not all of them are truly relevant if one is to
# predict outcome on the basis of intake information. We therefore eliminate eleven more variables and
# end up with a ten-column dataset. This simplification consists of three main steps.

# First, we simplify age upon intake by keeping only the column that gives the age in days.

# Second, we restrict time-related information to intake month and intake weekday, and drop all other
# time variables (datetime, year, monthyear and hour). We will therefore investigate whether the intake
# month and weekday have an impact on the outcome, but we will not carry out a similar investigation
# for other time-related variables.

# Third, we eliminate variables that do not reflect proprietary features of the animals in question:
# animal ID, found location, count and intake number (these "external" variables are clearly not the
# same as proprietary features like breed, color or sex).

df <- df %>%
  select(-c("age_upon_intake", "age_upon_intake_.years.", "age_upon_intake_age_group",
            "intake_datetime", "intake_year", "intake_monthyear", "intake_hour", "animal_id_intake",
            "found_location", "count", "intake_number"))





# Having reached the end of the variable selection process, we can now take a look at the list of the
# ten remaining variables.

names(df)





# In the following, we will provide a description of each variable and carry out some further wrangling
# when needed.

# Let us start by taking a look at summary statistics for the “outcome_type” column. This column
# indicates the outcome associated with each observation, e.g. whether an animal died, went missing,
# was returned to its owner, etc.

summary(df$outcome_type)





# For classification purposes, we will consider an outcome to be a “success” in three different cases:
# adoption, return to owner and “Rto-Adopt” (i.e. return to owner through the adoption process of the
# shelter).
# These three scenarios will be allocated the value of 1, while other scenarios will be allocated the
# value of 0 (in factor format).

df <- df %>%
  mutate(outcome_type = as.factor(ifelse(outcome_type %in% c("Adoption", "Return to Owner",
                                                             "Rto-Adopt"), 1, 0)))





# Then we take a look at summary statistics for the “animal_type” column. This column indicates the
# species of each animal, e.g. whether an animal is a dog, a cat, etc.

summary(df$animal_type)





# For classification purposes, we will only consider observations that correspond to a well-defined
# animal type: dog, cat or bird. 
# Hence we filter out the observations that fall under the “Other” category.

df <- subset(df, df$animal_type != "Other")





# We then turn to the “breed” column. This column indicates the breed of each animal, e.g. whether a
# dog belongs to the “Spinone Italiano Mix” breed or the “Shetland Sheepdog” breed.
# In this respect, we observe that the number of breeds is very large (2059 breeds).

n_distinct(df$breed)





# For classification purposes, we simplify the “breed” column by keeping only the first term of each
# breed. This will allow us to group more animals into the same breed category, e.g. dogs of the
# “Dachshund Mix” and “Dachshund Stan Mix” breeds will now be grouped into the same generic “Dachshund”
# breed.

df <- df %>%
  mutate(breed = str_extract(breed, "(\\w+)"))





# Having successfully performed this simplification, we observe that the number of breeds is now
# significantly lower (226 breeds).

n_distinct(df$breed)





# However, we need to check whether this simplification leads to overlapping breeds, i.e. breeds that
# are found across several animal types.

df %>%
  group_by(breed) %>%
  summarise(count_animal_types = n_distinct(animal_type)) %>%
  filter(count_animal_types > 1)





# We observe that there are four overlapping breeds. Research indicates that all these breeds concern
# cats and dogs, not birds.
# We now correct this problem. The idea is to rewrite “American” as “American (Dog)” for dogs, and as
# “American (Cat)” for cats. We do the same for the three other breeds.

df <- df %>%
  mutate(breed = if_else(animal_type == "Dog" & breed == "American", "American (Dog)", breed)) %>%
  mutate(breed = if_else(animal_type == "Cat" & breed == "American", "American (Cat)", breed)) %>%
  mutate(breed = if_else(animal_type == "Dog" & breed == "Japanese", "Japanese (Dog)", breed)) %>%
  mutate(breed = if_else(animal_type == "Cat" & breed == "Japanese", "Japanese (Cat)", breed)) %>%
  mutate(breed = if_else(animal_type == "Dog" & breed == "Norwegian", "Norwegian (Dog)", breed)) %>%
  mutate(breed = if_else(animal_type == "Cat" & breed == "Norwegian", "Norwegian (Cat)", breed)) %>%
  mutate(breed = if_else(animal_type == "Dog" & breed == "Scottish", "Scottish (Dog)", breed)) %>%
  mutate(breed = if_else(animal_type == "Cat" & breed == "Scottish", "Scottish (Cat)", breed))





# For verification purposes, we run once again the code that allowed us to identify the four
# overlapping breeds. As expected, we observe that no single row is displayed. We have thus
# successfully solved the problem of overlapping breeds.

df %>%
  group_by(breed) %>%
  summarise(count_animal_types = n_distinct(animal_type)) %>%
  filter(count_animal_types > 1)





# Then we take a look at the “color” column. Unsurprisingly, this column indicates the color of each
# animal, e.g. whether an animal is black or white. In this respect, we observe that the number of
# colors is very large (515 color categories).

n_distinct(df$color)





# For classification purposes, we simplify the “color” column by keeping only the first term of each
# color category. This will allow us to group more animals into the same color category, e.g. animals
# that are “Yellow/White” and “Yellow/Tan” will now be grouped into the same generic “Yellow” category.

# This simplification would not be appropriate if colors were listed by alphabetical order, as this
# would introduce a bias in favor of colors like “Black” and “Brown” over colors like “White” and
# “Yellow”. However, colors are not listed by alphabetical order (as can be seen with the
# “Yellow/White” example), but by order of importance. The simplification can thus be considered to be
# appropriate.

df <- df %>%
  mutate(color = str_extract(color, "(\\w+)"))





# Having successfully performed this simplification, we observe that the number of colors is now
# significantly lower (30 color categories).

n_distinct(df$color)





# We then turn to summary statistics for the “intake_condition” column. This column indicates the
# condition of each animal upon intake, e.g. whether an animal is injured, sick, pregnant, normal, etc.
# This column does not require additional data wrangling at this stage.

summary(df$intake_condition)





# Then we take a look at summary statistics for the “intake_type” column. This column gives the reason
# behind intake, i.e. the reason why an animal has been admitted to the shelter (e.g. euthanasia
# request, owner surrender, etc.).
# This column does not require additional data wrangling at this stage.

summary(df$intake_type)





# We then turn to summary statistics for the “sex_upon_intake” column. This column does not simply
# differentiate between males and females, but also makes a distinction between “intact” animals and
# “neutered” / “spayed” animals.

summary(df$sex_upon_intake)





# We can see that one observation does not have any label. We drop this row from the dataset.

df <- df %>%
  filter(sex_upon_intake %in% c("Intact Female", "Intact Male", "Neutered Male", "Spayed Female",
                                "Unknown"))





# Then we take a look at summary statistics for the “age_upon_intake_.days.” column. Unsurprisingly,
# this column indicates the age of each animal upon intake, in days.

summary(df$age_upon_intake_.days.)

# We can see that the age ranges from 0 days to 9125 days (i.e. 25 years). Furthermore, the mean
# (788.3 days) is more than twice as large as the median (365 days), indicating that the distribution
# is not symmetrical, but rather skewed to the right (visualization will be provided in chapter 3).





# For the sake of simplicity, we rename this column into “age_upon_intake_days”, thereby discarding
# the two unnecessary dots.

df <- df %>%
  rename(age_upon_intake_days = age_upon_intake_.days.)





# We then turn to summary statistics for the “intake_month” column. Unsurprisingly, this column
# indicates the month in which the intake of each animal took place.

class(df$intake_month)
summary(df$intake_month)





# We can see that the values in this column are integers. For classification purposes, we need them to
# be factors. Consequently, we convert months into factors, and display them as abbreviations.

df <- df %>%
  mutate(intake_month = as.factor(month(intake_month, label = TRUE)))





# Finally, we take a look at summary statistics for the “intake_weekday” column. Unsurprisingly, this
# column indicates the weekday in which the intake of each animal took place.

summary(df$intake_weekday)





# We can see that weekdays are not displayed in the usual order. We thus reorder factor levels to make
# sure that weekdays are ordered from Monday to Sunday.

df$intake_weekday <- factor(df$intake_weekday, levels = c("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"))
summary(df$intake_weekday)





# Finally, we convert every character column into factors, as this format is required for
# classification algorithms.

df <- df %>%
  mutate_if(is.character, as.factor)





# For verification purposes, we take a look at the class of each column. As expected, all columns are
# now in factor format, except the “age_upon_intake_days” column (which remains in the desired integer
# format).

sapply(df, class)





# We have now reached the end of section 2.1 (Data Cleaning). The end product of this section is a
# ten-column dataset, with one outcome variable (“outcome_type”) and nine predictors. The first five
# rows of this dataset are displayed below.

head(df, 5)





##########################################################
# 2.2 Data Partition
##########################################################


# The purpose of this section is to partition our dataset into the training, testing and hold-out sets
# required to perform machine learning tasks.

# More precisely, this partition is done in two steps.

# First, we split the “df” dataset into two sets: “df_train” and “hold_out_set”. The former will be
# used to train various machine learning models, while the latter will be used solely for the purpose
# of testing our best-performing model.

# Second, we split the “df_train” dataset into two sets: “training_set” and “testing_set”. For each
# machine learning model, we will use the former set to train the model (including parameter tuning),
# and the latter set to test it.

# This two-step partition reflects the partition method that is recommended for the MovieLens project
# of the HarvardX curriculum: one needs to first create a hold-out set (“validation” set for
# MovieLens), and then split the remaining observations (“edx” set for MovieLens) into a training set
# and a testing set.

# Before carrying out this two-step partition, a decision must be made on the partition split, i.e. the
# percentage of observations that will be allocated to each subset.

# In this regard, one faces a trade-off between the representativeness of training sets and testing
# sets: as one gradually increases the relative weight of the training set, one also gradually
# increases the risk of seeing the testing set become less and less representative of the total 
# population. In other words, the accuracy of a model may suffer from a lack of representativeness
# when the testing set is too small (in relative terms), meaning that the accuracy score may display
# important variance if the model is applied to different testing sets.

# In this project, a 90/10 split will be applied to each of the two partition steps. This implies that
# 81% of the original dataset (df) will end up being allocated to the “training_set” (as 0.90 * 0.90 =
# 0.81), 9% to the “testing_set” (as 0.90 * 0.10 = 0.09) and 10% to the “hold_out_set” (as 0.10 * 1.00
# = 0.10).

# With 81% of the observations allocated to the training set, our partition is very close to major
# partition examples provided in the HarvardX curriculum. Not only is this partition identical to the
# two-step partition recommended for the MovieLens project (two 90/10 splits), but it is also similar
# to the two main classification exercises of the “Machine Learning” course (Titanic and breast
# cancer), which allocate 80% of observations to the training set. Consequently, our approach can be
# considered to minimize the risk of sub-optimal data partition by deliberately aligning itself with
# these three best practices.





# Let us begin by splitting the “df” set into “df_train” and “hold_out_set”.
# The caret package is required to perform data partition. It has been automatically loaded at the
# beginning of section 2.1.

# start by setting the seed to 1 (as data partition involves randomness)
set.seed(1, sample.kind = "Rounding") # if using R 3.5 or earlier, remove the sample.kind argument

# create the index for a 90/10 split
hold_out_index <- createDataPartition(df$outcome_type, times = 1, p = 0.1, list = FALSE)

# split df into hold_out_set (10%) and df_train (90%)
hold_out_set <- df[hold_out_index, ]
df_train <- df[-hold_out_index, ]





# Then we split “df_train” into “training_set” and “testing_set”.
# Once this is done, we discard “df_train”, as it is no longer needed.

# start by setting the seed to 2 (as data partition involves randomness)
set.seed(2, sample.kind = "Rounding") # if using R 3.5 or earlier, remove the sample.kind argument

# create the index for a 90/10 split
test_index <- createDataPartition(df_train$outcome_type, times = 1, p = 0.1, list = FALSE)

# split df_train into testing_set (10%) and training_set (90%)
testing_set <- df[test_index, ]
training_set <- df[-test_index, ]

# discard df_train (no longer needed)
remove(df_train)





# We have now reached the end of section 2.2 (Data Partition). The end product of this section consists
# of three datasets, which will be used to carry out machine learning tasks: a training set, a testing
# set and a hold-out set (with the latter being used solely for the purpose of testing our
# best-performing model).





##########################################################
# 3. Data Exploration and Visualization
##########################################################


# Chapter 3 consists of nine sections, with each section exploring the relationship between the outcome
# variable (success v. non-success) and a predictor variable.
# In this respect, we make use of the training set defined at the end of section 2.2. The testing set
# and hold-out set are not used in this chapter.





##########################################################
# 3.1 Animal Type
##########################################################


# This section focuses on the second column of the training set, i.e. animal type.
# It explores the distribution of animal types, as well as the relationship of this predictor with the
# outcome variable.





# We first plot a bar chart to assess the distribution of animal types.

# start by extracting the total number of observations in the training set
# as this will be used in multiple plots in chapter 3
nrow_training_set <- nrow(training_set)

# then create the plot
training_set %>%
  group_by(animal_type) %>%
  summarise(proportion = n() / nrow_training_set) %>%
  ggplot(aes(x = reorder(animal_type, -proportion), y = proportion)) + # reorder from highest to
                                                                       # lowest proportion
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  geom_text(aes(label = paste0(round(proportion * 100, digits = 2), "%")), vjust = -0.25) + 
                                                                   # add proportion values on top of
                                                                   # each bar (in percentage format)
  ggtitle("Distribution of animal types") +
  xlab("") +
  ylab("")





# We observe that the distribution of animal types is definitely uneven, with birds accounting only
# for a tiny proportion of observations (0.45%), while dogs and cats represent large chunks of the
# dataset (respectively 60.31% and 39.25%).





# We now move on to a more interesting visualization task, namely the exploration of the relationship
# between the outcome variable and animal type (predictor).
# In order to do so, we plot a bar chart to assess the proportion of successful outcomes per animal
# type. We also add a horizontal line depicting the average proportion of successful outcomes across
# the entire training set.

# start by extracting the average proportion of successful outcomes across the entire training set
# as this will be used in multiple plots in chapter 3
# technical note: as.numeric(outcome_type) gives values of 1 or 2 (factors), hence we subtract 1 to
# get the desired values of 0 or 1
avg_proportion_success <- mean(as.numeric(training_set$outcome_type) - 1)

# then create the plot
training_set %>%
  group_by(animal_type) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1)) %>%
  ggplot(aes(x = reorder(animal_type, -proportion), y = proportion)) + # reorder from highest to lowest
                                                                       # success proportion
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  geom_text(aes(label = paste0(round(proportion * 100, digits = 2), "%")), vjust = -0.25) +
                                      # add proportion values on top of each bar (in percentage format)
  
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 3, y = avg_proportion_success + 0.03, label = "training set average"),
            color = "red") + # add a horizontal line for the average proportion,
                             # together with an appropriate label
  
  ggtitle("Proportion of successful outcomes per animal type") +
  xlab("") +
  ylab("")





# We observe that the proportion of successful outcomes is not homogeneous across animal types, with
# dogs being the only type with an above-average proportion of success.

# This is a finding that is worth keeping in mind, as this hints at the fact that animal type may play
# a role in a classification tree model (i.e. show up as a splitting criterion in a node) or in a
# random forest model (i.e. show up as one of the important variables identified by the model).

# Given that dogs are the most frequent animal type (as demonstrated by the first plot of this section),
# we can also postulate that the average proportion of success across the entire training set is
# impacted by animal type: as dogs make up both the most numerous and the most successful animal type,
# they probably contribute to driving up the training set average.





##########################################################
# 3.2 Breed
##########################################################


# This section focuses on the third column of the training set, i.e. breed.
# It explores the distribution of breeds, as well as the relationship of this predictor with the
# outcome variable.





# We first plot a bar chart to assess the distribution of breeds across animal types. More precisely,
# we want to assess the percentage of breeds that is associated with each animal type.

# start by extracting the total number of breeds in the training set
# as this will be used as denominator below (for computing the proportion of breeds per animal type)
nbreeds_training_set <- n_distinct(training_set$breed)

# then create the plot
training_set %>%
  group_by(animal_type) %>%
  summarise(proportion_breeds = n_distinct(breed) / nbreeds_training_set) %>%
  ggplot(aes(x = reorder(animal_type, -proportion_breeds), y = proportion_breeds)) + # reorder from highest to lowest proportion
  
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  geom_text(aes(label = paste0(round(proportion_breeds * 100, digits = 2), "%")), vjust = -0.25) + # add proportion values on top of each bar (in percentage format)
  
  ggtitle("Distribution of breeds across animal types") +
  xlab("") +
  ylab("")





# We observe that the distribution of breeds across animal types is uneven, with dogs accounting for
# 67.98% of breeds, while birds and cats only amount to approximately 16% (respectively 16.67% and
# 15.35%).
# However, the relative weight of dogs echoes the observation made in section 3.1, where it was
# demonstrated that dogs account for 60.31% of all animals. In this respect, the general shape of
# this plot is therefore not too surprising (with the exception of birds, which account for 16.67%
# of breeds but only 0.45% of all animals).





# We now move on to a more interesting visualization task, namely the exploration of the relationship
# between the outcome variable and breed.
# For each animal type, we will plot the ten breeds with the highest and lowest proportion of
# successful outcomes. Given that some breeds only display very few observations, we will filter out
# the 10% of breeds with the lowest number of observations before creating the desired charts. By
# doing so, we make sure that the plots are representative of broader tendencies across breeds,
# instead of being influenced by outliers.
# Let us first plot the ten dog breeds with the highest proportion of successful outcomes. We also add
# a horizontal line depicting the average proportion of successful outcomes across the entire training
# set.

training_set %>%
  filter(animal_type == "Dog") %>%
  group_by(breed) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1), count = n()) %>%
  filter(count > quantile(count, 0.10)) %>% # filter out the decile with the lowest number of
                                            # observations
  arrange(desc(proportion)) %>%
  head(10) %>% # take the top 10 breeds
  
  ggplot(aes(x = reorder(breed, -proportion), y = proportion)) + # reorder from highest to lowest
                                                                 # proportion
  geom_bar(stat = "identity") +
  coord_cartesian(ylim = c(0.5, 1)) +
  scale_y_continuous(labels = scales::percent_format()) +
  
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 1.73, y = avg_proportion_success + 0.03, label = "training set average"),
            color = "red") + # add a horizontal line for the average proportion,
                             # together with an appropriate label
  
  ggtitle("Top 10 dog breeds with the highest proportion of successful outcomes") +
  xlab("") +
  ylab("") +
  theme(axis.text.x = element_text(angle=90,hjust=1,vjust=0.5))





# We see that all ten breeds display an above-average proportion of success, with seven of them even
# reaching the 100% hallmark.





# We now move on to the ten dog breeds with the lowest proportion of successful outcomes.
# As usual, we also add a horizontal line depicting the average proportion of successful outcomes
# across the entire training set.

training_set %>%
  filter(animal_type == "Dog") %>%
  group_by(breed) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1), count = n()) %>%
  filter(count > quantile(count, 0.10)) %>% # filter out the decile with the lowest number of
                                            # observations
  arrange(proportion) %>%
  head(10) %>% # take the 10 worst breeds
  
  ggplot(aes(x = reorder(breed, proportion), y = proportion)) + # reorder from lowest to highest
                                                                # proportion
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 1.73, y = avg_proportion_success + 0.03, label = "training set average"),
            color = "red") + # add a horizontal line for the average proportion,
                             # together with an appropriate label
  
  ggtitle("Top 10 dog breeds with the lowest proportion of successful outcomes") +
  xlab("") +
  ylab("") +
  theme(axis.text.x = element_text(angle=90,hjust=1,vjust=0.5))





# We see that all ten breeds display a below-average proportion of success. However, the overall
# picture is not too bleak either: all ten breeds are above 30%, and five of them are even above 50%.





# Let us turn to the ten cat breeds with the highest proportion of successful outcomes. As usual, we
# also add a horizontal line depicting the average proportion of successful outcomes across the entire
# training set.

training_set %>%
  filter(animal_type == "Cat") %>%
  group_by(breed) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1), count = n()) %>%
  filter(count > quantile(count, 0.10)) %>% # filter out the decile with the lowest number of
                                            # observations
  arrange(desc(proportion)) %>%
  head(10) %>% # take the top 10 breeds
  
  ggplot(aes(x = reorder(breed, -proportion), y = proportion)) + # reorder from highest to lowest
                                                                 # proportion
  geom_bar(stat = "identity") +
  coord_cartesian(ylim = c(0.5, 1)) +
  scale_y_continuous(labels = scales::percent_format()) +
  
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 1.73, y = avg_proportion_success + 0.03, label = "training set average"),
            color = "red") + # add a horizontal line for the average proportion,
                             # together with an appropriate label
  
  ggtitle("Top 10 cat breeds with the highest proportion of successful outcomes") +
  xlab("") +
  ylab("") +
  theme(axis.text.x = element_text(angle=90,hjust=1,vjust=0.5))





# We see that all ten breeds display an above-average proportion of success, with six of them even
# reaching the 100% hallmark.





# We now move on to the ten cat breeds with the lowest proportion of successful outcomes. As usual,
# we also add a horizontal line depicting the average proportion of successful outcomes across the
# entire training set.

training_set %>%
  filter(animal_type == "Cat") %>%
  group_by(breed) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1), count = n()) %>%
  filter(count > quantile(count, 0.10)) %>% # filter out the decile with the lowest number of
                                            # observations
  arrange(proportion) %>%
  head(10) %>% # take the 10 worst breeds
  
  ggplot(aes(x = reorder(breed, proportion), y = proportion)) + # reorder from lowest to highest
                                                                # proportion
  
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 1.73, y = avg_proportion_success + 0.03, label = "training set average"),
            color = "red") + # add a horizontal line for the average proportion,
                             # together with an appropriate label
  
  ggtitle("Top 10 cat breeds with the lowest proportion of successful outcomes") +
  xlab("") +
  ylab("") +
  theme(axis.text.x = element_text(angle=90,hjust=1,vjust=0.5))





# We see that all ten breeds display a below-average proportion of success. Except for the “Exotic”
# breed (0% of success), the overall picture is not too bleak either: the other nine breeds are above
# 40%, and five of them are even above 50%.





# Let us turn to the ten bird breeds with the highest proportion of successful outcomes. As usual,
# we also add a horizontal line depicting the average proportion of successful outcomes across the
# entire training set.

training_set %>%
  filter(animal_type == "Bird") %>%
  group_by(breed) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1), count = n()) %>%
  filter(count > quantile(count, 0.10)) %>% # filter out the decile with the lowest number of
                                            # observations
  arrange(desc(proportion)) %>%
  head(10) %>% # take the top 10 breeds
  
  ggplot(aes(x = reorder(breed, -proportion), y = proportion)) + # reorder from highest to lowest
                                                                 # proportion
  geom_bar(stat = "identity") +
  coord_cartesian(ylim = c(0.5, 1)) +
  scale_y_continuous(labels = scales::percent_format()) +
  
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 9, y = avg_proportion_success + 0.03, label = "training set average"),
            color = "red") + # add a horizontal line for the average proportion,
                            # together with an appropriate label
  
  ggtitle("Top 10 bird breeds with the highest proportion of successful outcomes") +
  xlab("") +
  ylab("") +
  theme(axis.text.x = element_text(angle=90,hjust=1,vjust=0.5))





# We see that only the first six breeds display an above-average proportion of success, with two of
# them reaching the 100% hallmark.





# Finally, we move on to the ten bird breeds with the lowest proportion of successful outcomes.
# As usual, we also add a horizontal line depicting the average proportion of successful outcomes
# across the entire training set.

training_set %>%
  filter(animal_type == "Bird") %>%
  group_by(breed) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1), count = n()) %>%
  filter(count > quantile(count, 0.10)) %>% # filter out the decile with the lowest number of
                                            # observations
  
  arrange(proportion) %>%
  head(10) %>% # take the 10 worst breeds
  
  ggplot(aes(x = reorder(breed, proportion), y = proportion)) + # reorder from lowest to highest
                                                                # proportion
  
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 1.73, y = avg_proportion_success + 0.03, label = "training set average"),
            color = "red") + # add a horizontal line for the average proportion,
                             # together with an appropriate label
  
  ggtitle("Top 10 bird breeds with the lowest proportion of successful outcomes") +
  xlab("") +
  ylab("") +
  theme(axis.text.x = element_text(angle=90,hjust=1,vjust=0.5))





# We see that all ten breeds display a below-average proportion of success. In addition, the overall
# picture is bleaker than in the case of dogs and cats, as eight breeds have 0% of success.





# We have now reached the end of section 3.2. We have demonstrated that the proportion of successful
# outcomes is not homogeneous across breeds. On the contrary, significant variations exist across
# breeds, as illustrated by our plots of the ten most successful and least successful breeds.

# This is a finding that is worth keeping in mind, as this hints at the fact that breed may play a
# role in a classification tree model (i.e. show up as a splitting criterion in a node) or in a
# random forest model (i.e. show up as one of the important variables identified by the model).





##########################################################
# 3.3 Color
##########################################################


# This section focuses on the fourth column of the training set, i.e. color.
# It explores the distribution of color categories, as well as the relationship of this predictor
# with the outcome variable.





# We first plot a bar chart to assess the distribution of color categories.

training_set %>%
  group_by(color) %>%
  summarise(proportion = n() / nrow_training_set) %>%
  ggplot(aes(x = reorder(color, -proportion), y = proportion)) + # reorder from highest to lowest
                                                                 # proportion
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  
  ggtitle("Distribution of color categories") +
  xlab("") +
  ylab("") +
  theme(axis.text.x = element_text(angle=90,hjust=1,vjust=0.5))





# We observe that the distribution of color categories is definitely uneven. While black and brown
# account for more than 45% of observations, only five color categories are above the 5% threshold,
# and most categories are found below the 2.5% threshold.





# We now move on to a more interesting visualization task, namely the exploration of the relationship
# between the outcome variable and color.
# Similarly to what has been done in section 3.2, we will plot the ten color categories with the
# highest and lowest proportion of successful outcomes. Given that some categories only display very
# few observations, we will filter out the 10% of categories with the lowest number of observations
# before creating the desired charts. By doing so, we make sure that the plots are representative of
# broader tendencies across color categories, instead of being influenced by outliers.





# Let us first plot the ten color categories with the highest proportion of successful outcomes.
# We also add a horizontal line depicting the average proportion of successful outcomes across the
# entire training set.

training_set %>%
  group_by(color) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1), count = n()) %>%
  filter(count > quantile(count, 0.10)) %>% # filter out the decile with the lowest number of
                                            # observations
  arrange(desc(proportion)) %>%
  head(10) %>% # take the top 10 color categories
  
  ggplot(aes(x = reorder(color, -proportion), y = proportion)) + # reorder from highest to lowest
                                                                 # proportion
  geom_bar(stat = "identity") +
  coord_cartesian(ylim = c(0.5, 1)) +
  scale_y_continuous(labels = scales::percent_format()) +
  
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 1.73, y = avg_proportion_success - 0.02, label = "training set average"),
            color = "red") + # add a horizontal line for the average proportion,
                             # together with an appropriate label
  
  ggtitle("Top 10 color categories with the highest proportion of successful outcomes") +
  xlab("") +
  ylab("") +
  theme(axis.text.x = element_text(angle=90,hjust=1,vjust=0.5))





# We see that all ten color categories display an above-average proportion of success. However,
# the overall picture is rather homogeneous, as all categories are found in the range between 70%
# and 80% of success. This is in clear contrast to the plots of section 3.2, where the top-10
# rankings displayed higher proportions of success and even contained some categories with 100%
# of success.





# We now move on to the ten color categories with the lowest proportion of successful outcomes.
# As usual, we also add a horizontal line depicting the average proportion of successful outcomes
# across the entire training set.

training_set %>%
  group_by(color) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1), count = n()) %>%
  filter(count > quantile(count, 0.10)) %>% # filter out the decile with the lowest number
                                            # of observations
  arrange(proportion) %>%
  head(10) %>% # take the 10 worst color categories
  
  ggplot(aes(x = reorder(color, proportion), y = proportion)) + # reorder from lowest to highest
                                                                # proportion
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 1.73, y = avg_proportion_success + 0.03, label = "training set average"),
            color = "red") + # add a horizontal line for the average proportion,
                             # together with an appropriate label
  
  ggtitle("Top 10 color categories with the lowest proportion of successful outcomes") +
  xlab("") +
  ylab("") +
  theme(axis.text.x = element_text(angle=90,hjust=1,vjust=0.5))





# We see that all ten color categories display a below-average proportion of success. However, the
# overall picture is once again rather homogeneous, as all categories are found in the range between
# 45% and 60% of success.





# We have now reached the end of section 3.3. We have demonstrated that the proportion of successful
# outcomes is not perfectly homogeneous across color categories. On the contrary, variations exist
# across color categories, as illustrated by our plots of the ten most successful and least successful
# categories. Nevertheless, these variations are clearly less significant than those observed in
# section 3.2 (breeds).

# This is a finding that is worth keeping in mind, as this hints at the fact that color may not
# necessarily play a major role in a classification tree model (i.e. show up as a splitting criterion
# in a node) or in a random forest model (i.e. show up as one of the important variables identified
# by the model).





##########################################################
# 3.4 Intake Condition
##########################################################


# This section focuses on the fifth column of the training set, i.e. intake condition.
# It explores the distribution of intake conditions, as well as the relationship of this predictor
# with the outcome variable.





# We first plot a bar chart to assess the distribution of intake conditions.

training_set %>%
  group_by(intake_condition) %>%
  summarise(proportion = n() / nrow_training_set) %>%
  ggplot(aes(x = reorder(intake_condition, -proportion), y = proportion)) + # reorder from highest to
                                                                            # lowest proportion
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  geom_text(aes(label = paste0(round(proportion * 100, digits = 2), "%")), vjust = -0.25) + 
  # add proportion values on top of each bar (in percentage format)
  
  ggtitle("Distribution of intake conditions") +
  xlab("") +
  ylab("")





# We observe that the distribution of intake conditions is definitely uneven, with the “normal”
# condition accounting for 89.4% of observations, while no other condition reaches the 5% threshold.
# Four conditions are even found below the 1% threshold.





# We now move on to a more interesting visualization task, namely the exploration of the relationship
# between the outcome variable and intake condition.
# In order to do so, we plot a bar chart to assess the proportion of successful outcomes for each
# intake condition. We also add a horizontal line depicting the average proportion of successful
# outcomes across the entire training set.

training_set %>%
  group_by(intake_condition) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1)) %>%
  ggplot(aes(x = reorder(intake_condition, -proportion), y = proportion)) + # reorder from highest to
                                                                           # lowest success proportion
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  geom_text(aes(label = paste0(round(proportion * 100, digits = 2), "%")), vjust = -0.25) + 
  # add proportion values on top of each bar (in percentage format)
  
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 7.5, y = avg_proportion_success + 0.03, label = "training set average"),
            color = "red") + # add a horizontal line for the average proportion,
                            # together with an appropriate label
  
  ggtitle("Proportion of successful outcomes for each intake condition") +
  xlab("") +
  ylab("")





# We observe that the proportion of successful outcomes is not homogeneous across intake conditions,
# with the “normal” condition being the only one with an above-average proportion of success.

# This is a finding that is worth keeping in mind, as this hints at the fact that intake condition
# may play a role in a classification tree model (i.e. show up as a splitting criterion in a node)
# or in a random forest model (i.e. show up as one of the important variables identified by the model).





##########################################################
# 3.5 Intake Type
##########################################################


# This section focuses on the sixth column of the training set, i.e. intake type.
# It explores the distribution of intake types, as well as the relationship of this predictor
# with the outcome variable.





# We first plot a bar chart to assess the distribution of intake types.

training_set %>%
  group_by(intake_type) %>%
  summarise(proportion = n() / nrow_training_set) %>%
  ggplot(aes(x = reorder(intake_type, -proportion), y = proportion)) + # reorder from highest to
                                                                       # lowest proportion
  
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  geom_text(aes(label = paste0(round(proportion * 100, digits = 2), "%")), vjust = -0.25) + 
  # add proportion values on top of each bar (in percentage format)
  
  ggtitle("Distribution of intake types") +
  xlab("") +
  ylab("")





# We observe that the distribution of intake types is definitely uneven, with the “stray” type
# accounting for 73.6% of observations. The other significant intake type is “Owner Surrender”
# (19.53%). The three other types are rather marginal and fail to reach the 10% threshold, with
# “Euthanasia Request” and “Wildlife” even falling below the 1% threshold.





# We now move on to a more interesting visualization task, namely the exploration of the relationship
# between the outcome variable and intake type.
# In order to do so, we plot a bar chart to assess the proportion of successful outcomes for each
# intake type. We also add a horizontal line depicting the average proportion of successful outcomes
# across the entire training set.

training_set %>%
  group_by(intake_type) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1)) %>%
  ggplot(aes(x = reorder(intake_type, -proportion), y = proportion)) + # reorder from highest to
                                                                       # lowest success proportion
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  geom_text(aes(label = paste0(round(proportion * 100, digits = 2), "%")), vjust = -0.25) + 
  # add proportion values on top of each bar (in percentage format)
  
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 4.5, y = avg_proportion_success + 0.03, label = "training set average"),
            color = "red") + # add a horizontal line for the average proportion,
                             # together with an appropriate label
  
  ggtitle("Proportion of successful outcomes for each intake type") +
  xlab("") +
  ylab("")





# We observe that the proportion of successful outcomes is not homogeneous across intake types.
# “Public Assist” is clearly above the training set average, “Owner Surrender” and “Stray” are both
# close to the average, but “Euthanasia Request” and “Wildlife” take very low values (8.11% and 3.33%
# respectively).

# This is a finding that is worth keeping in mind, as this hints at the fact that intake type may
# play a role in a classification tree model (i.e. show up as a splitting criterion in a node) or in
# a random forest model (i.e. show up as one of the important variables identified by the model).





##########################################################
# 3.6 Sex upon Intake
##########################################################


# This section focuses on the seventh column of the training set, i.e. sex upon intake.
# It explores the distribution of sex upon intake, as well as the relationship of this predictor
# with the outcome variable.





# We first plot a bar chart to assess the distribution of sex upon intake.

training_set %>%
  group_by(sex_upon_intake) %>%
  summarise(proportion = n() / nrow_training_set) %>%
  ggplot(aes(x = reorder(sex_upon_intake, -proportion), y = proportion)) + # reorder from highest
                                                                           # to lowest proportion
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  geom_text(aes(label = paste0(round(proportion * 100, digits = 2), "%")), vjust = -0.25) + 
  # add proportion values on top of each bar (in percentage format)
  
  ggtitle("Distribution of sex upon intake") +
  xlab("") +
  ylab("")





# We observe that the distribution of sex upon intake seems to follow some kind of pattern, with
# “intact” males and females being the largest group (approximately 32% each), followed by “neutered”
# and “spayed” animals (approximately 15% each). Animals of unknown sex only represent 4% of
# observations.





# We now move on to a more interesting visualization task, namely the exploration of the relationship
# between the outcome variable and sex upon intake.
# In order to do so, we plot a bar chart to assess the proportion of successful outcomes for each
# category of sex upon intake. We also add a horizontal line depicting the average proportion of
# successful outcomes across the entire training set.

training_set %>%
  group_by(sex_upon_intake) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1)) %>%
  ggplot(aes(x = reorder(sex_upon_intake, -proportion), y = proportion)) + # reorder from highest
                                                                        # to lowest success proportion
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  geom_text(aes(label = paste0(round(proportion * 100, digits = 2), "%")), vjust = -0.25) +
  # add proportion values on top of each bar (in percentage format)
  
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 5, y = avg_proportion_success + 0.03, label = "training set average"),
            color = "red") + # add a horizontal line for the average proportion,
                             # together with an appropriate label
  
  ggtitle("Proportion of successful outcomes for each category of sex upon intake") +
  xlab("") +
  ylab("")





# We observe that the proportion of successful outcomes is not homogeneous across the various
# categories of sex upon intake. Once again, we can identify some kind of pattern, with “spayed” and
# “neutered” animals having above-average proportions of success (approximately 76% each), while
# “intact” males and females are slightly below the average (approximately 62% each). Animals of
# unknown sex perform a lot worse, with only 3.95% of success.

# This is a finding that is worth keeping in mind, as this hints at the fact that sex upon intake may
# play a role in a classification tree model (i.e. show up as a splitting criterion in a node) or in 
# a random forest model (i.e. show up as one of the important variables identified by the model).





##########################################################
# 3.7 Age upon Intake
##########################################################


# This section focuses on the eighth column of the training set, i.e. age upon intake (in days).
# It explores the distribution of age upon intake, as well as the relationship of this predictor
# with the outcome variable.





# We first plot a histogram to assess the distribution of age upon intake.

# start by extracting the mean and median age in the training set
# as they will be used in multiple plots in section 3.7
mean_age = mean(training_set$age_upon_intake_days)
median_age = median(training_set$age_upon_intake_days)

# then create the plot
training_set %>%
  ggplot(aes(age_upon_intake_days)) +
  geom_histogram(bins = 25, color = "black") +
  
  geom_vline(aes(xintercept = median_age), color = "red", linetype = "dashed") +
  geom_text(aes(x = -100, y = 26000, label = "median"), color = "red") +
  geom_vline(aes(xintercept = mean_age), color = "blue", linetype = "dashed") +
  geom_text(aes(x = 1175, y = 26000, label = "mean"), color = "blue") +
  
  xlab("age upon intake (days)") +
  ylab("count") +
  ggtitle("Distribution of age upon intake (histogram)")





# This histogram provides a visual confirmation of the statements made in section 2.1.
# As a reminder, we observed in section 2.1 that the mean age is more than twice as large as the
# median age, indicating that the distribution is not symmetrical, but rather skewed to the right.
# This is confirmed by the shape of the histogram, as the right tail of the chart is definitely
# longer than the left tail.





# Due to the distribution being asymmetrical, it may not be sufficient to rely solely on a histogram
# to visualize the distribution of age upon intake.
# We therefore complement this histogram by plotting a simple line chart.

training_set %>%
  group_by(age_upon_intake_days) %>%
  summarise(count = n()) %>%
  ggplot(aes(age_upon_intake_days, count)) +
  geom_line() +
  
  geom_vline(aes(xintercept = median_age), color = "red", linetype = "dashed") +
  geom_text(aes(x = -100, y = 12000, label = "median"), color = "red") +
  geom_vline(aes(xintercept = mean_age), color = "blue", linetype = "dashed") +
  geom_text(aes(x = 1175, y = 12000, label = "mean"), color = "blue") +
  
  xlab("age upon intake (days)") +
  ylab("count") +
  ggtitle("Distribution of age upon intake (line chart)")





# This line chart enables us to identify one interesting pattern: age upon intake seems to take many
# different values when the age is small (0-365 days), but less and less values as the age becomes
# larger.
# Visually, this implies that the left part of the chart is very “granular” and “spiky” (because many
# different age values are represented), while the right part of the chart is “smoother” (because
# only few age values are represented).





# With this in mind, we “zoom in” on the left part of the chart and take a closer look at the
# distribution of age upon intake over the first three years.

training_set %>%
  filter(age_upon_intake_days <= 3 * 365) %>% # select only the first three years
  
  group_by(age_upon_intake_days) %>%
  summarise(count = n()) %>%
  ggplot(aes(age_upon_intake_days, count)) +
  geom_line() +
  
  # add vertical lines representing each year
  geom_vline(aes(xintercept = 365), color = "blue", linetype = "dashed") +
  geom_text(aes(x = 309, y = 12000, label = "1 year"), color = "blue") +
  geom_vline(aes(xintercept = 730), color = "blue", linetype = "dashed") +
  geom_text(aes(x = 665, y = 12000, label = "2 years"), color = "blue") +
  geom_vline(aes(xintercept = 1095), color = "blue", linetype = "dashed") +
  geom_text(aes(x = 1030, y = 12000, label = "3 years"), color = "blue") +
  
  xlab("age upon intake (days)") +
  ylab("count") +
  ggtitle("Distribution of age upon intake (first three years)")





# This chart confirms the statement made above: we can clearly see that the chart becomes less and
# less “granular” as the age becomes larger. Indeed, age upon intake takes several different values
# in the first year, but only takes “full-year” values for years 2 and 3.





# With this in mind, we “zoom in” once again and take a closer look at the distribution of age upon
# intake over the first year.

training_set %>%
  filter(age_upon_intake_days <= 365) %>% # select only the first year
  
  group_by(age_upon_intake_days) %>%
  summarise(count = n()) %>%
  ggplot(aes(age_upon_intake_days, count)) +
  geom_line() +
  
  # add vertical lines representing each quarter
  geom_vline(aes(xintercept = 365 / 4), color = "blue", linetype = "dashed") +
  geom_text(aes(x = 70, y = 12000, label = "3 months"), color = "blue") +
  geom_vline(aes(xintercept = 365 / 2), color = "blue", linetype = "dashed") +
  geom_text(aes(x = 160, y = 12000, label = "6 months"), color = "blue") +
  geom_vline(aes(xintercept = 365 * (3/4)), color = "blue", linetype = "dashed") +
  geom_text(aes(x = 253, y = 12000, label = "9 months"), color = "blue") +
  geom_vline(aes(xintercept = 365), color = "blue", linetype = "dashed") +
  geom_text(aes(x = 340, y = 12000, label = "12 months"), color = "blue") +
  
  xlab("age upon intake (days)") +
  ylab("count") +
  ggtitle("Distribution of age upon intake (first year)")





# Once again, we can see that the chart becomes less “granular” as age upon intake increases, with
# a clear contrast between the first quarter (up to 3 months) and the three following quarters.





# We now move on to a more interesting visualization task, namely the exploration of the relationship
# between the outcome variable and age upon intake.
# In order to do so, we plot a line chart to assess the proportion of successful outcomes for each
# individual value of age upon intake. We also add a horizontal line depicting the average proportion
# of successful outcomes across the entire training set.

training_set %>%
  group_by(age_upon_intake_days) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1)) %>%
  ggplot(aes(age_upon_intake_days, proportion)) +
  geom_line() +
  scale_y_continuous(labels = scales::percent_format()) +
  
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 2000, y = avg_proportion_success-0.02, label = "training set average"), color = "red") +
  
  ggtitle("Proportion of successful outcomes on the basis of age upon intake") +
  xlab("age upon intake (days)") +
  ylab("")





# While this line chart confirms once again that the distribution of age upon intake is more
# “granular” for small age values, one may not find it particularly easy to identify a meaningful
# trend on the basis of this plot.
# We therefore complement this line chart with a second plot. We now display the proportion of
# successful outcomes by means of a scatter plot (one dot representing one age value), and we add a
# trend line over this scatter plot.

training_set %>%
  group_by(age_upon_intake_days) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1)) %>%
  ggplot(aes(age_upon_intake_days, proportion)) +
  geom_point(color = "red", alpha = 0.2, size = 2) +
  geom_smooth() +
  scale_y_continuous(labels = scales::percent_format()) +
  
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 2000, y = avg_proportion_success-0.02, label = "training set average"), color = "red") +
  
  ggtitle("Proportion of successful outcomes on the basis of age upon intake") +
  xlab("age upon intake (days)") +
  ylab("")





# While we lose some of the precision brought by the first plot (line chart), we can now better
# observe the main trend behind this plot.
# We see that the proportion of successful outcomes tends to be significantly below-average for
# the very smallest age values, and it then peaks around 75% after 3 years. This peak is followed
# by a slow decline, with the trend line only falling below the average when the age exceeds
# 6000 days.





# Similarly to what has been done before, we will now “zoom in” on smaller age values in order to
# better analyze how the proportion of successful outcomes evolves in this part of the age range.
# We reproduce the first plot (line chart), but now we focus on the first three years of age.

training_set %>%
  filter(age_upon_intake_days <= 3 * 365) %>% # select only the first three years
  
  group_by(age_upon_intake_days) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1)) %>%
  ggplot(aes(age_upon_intake_days, proportion)) +
  geom_line() +
  scale_y_continuous(labels = scales::percent_format()) +
  
  # add a horizontal line representing the training set average
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 900, y = avg_proportion_success-0.02, label = "training set average"), color = "red") +
  
  # add vertical lines representing each year
  geom_vline(aes(xintercept = 365), color = "blue", linetype = "dashed") +
  geom_text(aes(x = 309, y = 0.20, label = "1 year"), color = "blue") +
  geom_vline(aes(xintercept = 730), color = "blue", linetype = "dashed") +
  geom_text(aes(x = 665, y = 0.20, label = "2 years"), color = "blue") +
  geom_vline(aes(xintercept = 1095), color = "blue", linetype = "dashed") +
  geom_text(aes(x = 1030, y = 0.20, label = "3 years"), color = "blue") +
  
  ggtitle("Proportion of successful outcomes in the first three years") +
  xlab("age upon intake (days)") +
  ylab("")





# This chart confirms the observation that the very smallest age values tend to be associated with
# a below-average proportion of success. In contrast, the rest of the chart display mostly
# above-average values.
# With this in mind, we create a last plot for section 3.7 by “zooming in” once again, this time
# on the first year of age.

training_set %>%
  filter(age_upon_intake_days <= 365) %>% # select only the first year
  
  group_by(age_upon_intake_days) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1)) %>%
  ggplot(aes(age_upon_intake_days, proportion)) +
  geom_line() +
  scale_y_continuous(labels = scales::percent_format()) +
  
  # add a horizontal line representing the training set average
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 320, y = avg_proportion_success-0.02, label = "training set average"), color = "red") +
  
  # add vertical lines representing each quarter
  geom_vline(aes(xintercept = 365 / 4), color = "blue", linetype = "dashed") +
  geom_text(aes(x = 70, y = 0.2, label = "3 months"), color = "blue") +
  geom_vline(aes(xintercept = 365 / 2), color = "blue", linetype = "dashed") +
  geom_text(aes(x = 160, y = 0.2, label = "6 months"), color = "blue") +
  geom_vline(aes(xintercept = 365 * (3/4)), color = "blue", linetype = "dashed") +
  geom_text(aes(x = 253, y = 0.2, label = "9 months"), color = "blue") +
  geom_vline(aes(xintercept = 365), color = "blue", linetype = "dashed") +
  geom_text(aes(x = 340, y = 0.2, label = "12 months"), color = "blue") +
  
  ggtitle("Proportion of successful outcomes in the first year") +
  xlab("age upon intake (days)") +
  ylab("")





# This plot enables us to refine the observation made above regarding the tendency for small age
# values to be associated with a below-average proportion of success.
# Indeed, we observe that this tendency holds for age values that are inferior to one month
# (30 days), while other age values tend to hover around the training set average.





# We have now reached the end of section 3.7. We have demonstrated that the proportion of successful
# outcomes is not perfectly homogeneous across different values of age upon intake. On the contrary,
# variations exist across age values, as illustrated by the four last plots of this section – with
# age values inferior to one month being associated with below-average proportions of success.

# This is a finding that is worth keeping in mind, as this hints at the fact that age upon intake
# may play a role in a classification tree model (i.e. show up as a splitting criterion in a node)
# or in a random forest model (i.e. show up as one of the important variables identified by the
# model).





##########################################################
# 3.8 Intake Month
##########################################################


# This section focuses on the ninth column of the training set, i.e. intake month.
# It explores the distribution of intake months, as well as the relationship of this predictor
# with the outcome variable.

# We first plot a bar chart to assess the distribution of intake months.

training_set %>%
  group_by(intake_month) %>%
  summarise(proportion = n() / nrow_training_set) %>%
  ggplot(aes(x = intake_month, y = proportion)) + 
  
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  
  # add a horizontal line representing a uniform distribution (1/12 for each month)
  geom_hline(aes(yintercept = 1/12), color = "red", linetype = "dashed") +
  geom_text(aes(x = 2.5, y = 0.0875, label = "uniform distribution (8.33%)"), color = "red") +
  
  ggtitle("Distribution of intake months") +
  xlab("") +
  ylab("")





# While we can identify peaks in May-June and October, this chart nevertheless indicates that the
# distribution of intake months is not too heterogeneous. Indeed, intake months do not display
# massive deviations from the value of 8.33% that would result from a perfectly uniform distribution.





# We now move on to a more interesting visualization task, namely the exploration of the relationship
# between the outcome variable and intake month.
# In order to do so, we plot a bar chart to assess the proportion of successful outcomes for each
# month. We also add a horizontal line depicting the average proportion of successful outcomes
# across the entire training set.

training_set %>%
  group_by(intake_month) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1)) %>%
  ggplot(aes(x = intake_month, y = proportion)) + 
  
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 6.5, y = avg_proportion_success + 0.03, label = "training set average"), color = "red") + # add a horizontal line for the average proportion, together with an appropriate label
  
  ggtitle("Proportion of successful outcomes for each intake month") +
  xlab("") +
  ylab("")





# Once again, we observe that the picture is rather homogeneous across intake months. There is only
# little variation from one month to the other, and all twelve months display a proportion of
# successful outcomes that is rather close to the training set average.
# This is a finding that is worth keeping in mind, as this hints at the fact that intake months may
# not necessarily play a major role in a classification tree model (i.e. show up as a splitting
# criterion in a node) or in a random forest model (i.e. show up as one of the important variables
# identified by the model).





##########################################################
# 3.9 Intake Weekday
##########################################################


# This section focuses on the tenth and last column of the training set, i.e. intake weekday.
# It explores the distribution of intake weekdays, as well as the relationship of this predictor
# with the outcome variable.

training_set %>%
  group_by(intake_weekday) %>%
  summarise(proportion = n() / nrow_training_set) %>%
  ggplot(aes(x = intake_weekday, y = proportion)) + 
  
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  
  # add a horizontal line representing a uniform distribution (1/7 for each weekday)
  geom_hline(aes(yintercept = 1/7), color = "red", linetype = "dashed") +
  geom_text(aes(x = 4, y = 0.15, label = "uniform distribution (14.29%)"), color = "red") +
  
  ggtitle("Distribution of intake weekdays") +
  xlab("") +
  ylab("")





# While we can identify a peak on Saturdays and a trough on Sundays, this chart nevertheless
# indicates that the distribution of intake weekdays is not too heterogeneous. Indeed, intake
# weekdays do not display massive deviations from the value of 14.29% that would result from a
# perfectly uniform distribution.





# We now move on to a more interesting visualization task, namely the exploration of the
# relationship between the outcome variable and intake weekday.
# In order to do so, we plot a bar chart to assess the proportion of successful outcomes for each
# weekday. We also add a horizontal line depicting the average proportion of successful outcomes
# across the entire training set.

training_set %>%
  group_by(intake_weekday) %>%
  summarise(proportion = mean(as.numeric(outcome_type) - 1)) %>%
  ggplot(aes(x = intake_weekday, y = proportion)) + 
  
  geom_bar(stat = "identity") +
  scale_y_continuous(labels = scales::percent_format()) +
  
  geom_hline(aes(yintercept = avg_proportion_success), color = "red", linetype = "dashed") +
  geom_text(aes(x = 1.5, y = avg_proportion_success + 0.03, label = "training set average"), color = "red") + # add a horizontal line for the average proportion, together with an appropriate label
  
  ggtitle("Proportion of successful outcomes for each intake weekday") +
  xlab("") +
  ylab("")





# Once again, we observe that the picture is rather homogeneous across intake weekdays. There is only
# little variation from one day to the other, and all seven days display a proportion of successful
# outcomes that is rather close to the training set average.
# This is a finding that is worth keeping in mind, as this hints at the fact that intake weekdays may
# not necessarily play a major role in a classification tree model (i.e. show up as a splitting
# criterion in a node) or in a random forest model (i.e. show up as one of the important variables
# identified by the model).





# We have now reached the end of Chapter 3 (Data Exploration and Visualization).
# Each section has explored the relationship between the outcome variable (success v. non-success)
# and a predictor variable.
# In this respect, we have been able to identify some preliminary patterns that may have an impact
# on classification algorithms. For instance, the proportion of successful outcomes has been shown
# to vary rather importantly across animal types and breeds, as well as intake conditions and
# intake types. # On the contrary, the impact of intake months and intake weekdays does not appear
# to be significant.





##########################################################
# 4. Modeling Approach
##########################################################


# Chapter 4 (Modeling Approach) consists of seven sections. The first section (4.1) gives an
# overview of the modeling approach of this report and introduces the various machine learning
# models deployed in the next five sections (4.2 to 4.6) – namely a baseline model, followed by
# logistic regression, knn, classification tree and random forest. The last section (4.7) tests
# the best-performing model on the basis of the hold-out set.





##########################################################
# 4.1 Overview
##########################################################


# This section gives an overview of the modeling approach of this report and introduces the various
# machine learning models deployed in the next five sections (4.2 to 4.6).

# As a benchmark, we begin by running a baseline model that classifies every observation as a
# success (section 4.2).
# The accuracy score will be given by the proportion of successful outcomes in the testing set: all
# successful outcomes get predicted correctly, and all non-successful outcomes get predicted
# incorrectly. While this model is not very interesting per se, we will use it as a benchmark to
# assess whether the accuracy of the next models is significantly better or not.

# In section 4.3, we deploy a logistic regression model.
# It seems justified to begin our modeling journey with this algorithm, as it is one of the most
# basic classification algorithms one could implement. It is indeed a mere adaptation of the linear
# regression model to classification tasks. By means of a simple logistic transformation, we can
# convert the output of linear regression into probabilities between 0 and 1. A decision rule can then
# be deployed to assign classes to these probabilities on the basis of the critical threshold of 0.5
# (i.e. “class 1” if the probability is above 0.5 and “class 0” in other cases).

# After having performed logistic regression, we will assess in section 4.4 whether higher predictive
# capabilities can be obtained with the k-nearest neighbors model (knn).
# This model is a logical next step in our modeling journey, in the sense that it offers more
# sophistication than a simple logistic regression, while at the same time remaining rather easy to
# implement. The key idea behind this model is to assign to an observation the class that is the most
# frequent among its k nearest neighbors – with k being a tuning parameter that can be optimized by
# means of cross-validation.

# The next step in our modeling journey involves the deployment of models that are more “transparent”
# in terms of the importance of individual variables.
# Indeed, neither logistic regression nor knn enable us to get any meaningful insight on the
# predictive power of each variable (such as animal type or breed). It therefore seems justified to
# complement these first two models with a set of models that offer more room for the interpretation
# of the importance of variables.

# In this regard, we first deploy a classification tree (section 4.5). This model offers us a first
# insight on the predictive power of variables, as we get to see which variables have been selected
# as splitting criteria in nodes.

# After having grown a classification tree, the logical next step is to add a layer of sophistication
# to this model by deploying a random forest algorithm (section 4.6).
# Indeed, this model builds upon the concept of classification trees by growing multiple trees. Each
# tree is grown on the basis of a random subset of predictors, with this randomness helping us reduce
# the correlation between individual trees. Once the entire forest has been grown, we can get an
# indication of the importance of individual variables by looking at which variables have been used
# most frequently as splitting criteria in tree nodes.

# To sum up, our modeling approach consists of five steps, with a baseline model being followed by
# four actual algorithms. With regard to these four algorithms, we start with a basic logistic
# regression, and then move on to a more sophisticated model, namely knn. As none of these algorithms
# allow for an identification of important variables, we then deploy two models that are more
# “transparent”. In doing so, we first grow a classification tree, and then add a layer of
# sophistication by growing a random forest.

# Each of these four algorithms will be trained on the basis of the training set (including
# optimization of tuning parameters when necessary) – i.e. the set called “training_set” in this
# script.

# Each algorithm will be tested on the basis of the testing set – i.e. the set called “testing_set”
# in this script.

# Finally, the best-performing algorithm will be tested once again on the basis of the hold-out set
# – i.e. the set called “hold_out_set” in this script. This will be done in section 4.7.

# As a metric to assess the predictive power of these algorithms, we will use the classification
# accuracy, i.e. the percentage of observations that are classified correctly by each algorithm.





##########################################################
# 4.2 Baseline Model
##########################################################


# This section deploys a baseline model that classifies every observation as a success.

# As a reminder, it has been shown in chapter 3 that the proportion of successful outcomes is above
# 50% in the training set (approximately 64.23%). Consequently, it makes sense to start our modeling
# journey by predicting every observation to be a success, i.e. to belong to “class 1”.





# We implement this prediction by creating a vector y_hat_baseline that only takes the value 1 (as
# opposed to 0), and that has the same number of rows as the testing set.

y_hat_baseline <- rep(1, nrow(testing_set)) %>% factor





# Then we can extract the accuracy of this baseline model (on the basis of the testing set).
# We also display it in a table that will collect the accuracy score of each algorithm.

# first we extract the accuracy score
accuracy_baseline <- confusionMatrix(y_hat_baseline, testing_set$outcome_type)$overall[["Accuracy"]]
# accuracy_baseline = 0.6379743

# then we store the accuracy score in a table and display this table
accuracy_scores <- data_frame(section = "4.2", model = "baseline", accuracy = accuracy_baseline)
accuracy_scores





# We see that the baseline accuracy is approximately 63.80%. This result is unsurprising, as it
# simply corresponds to the proportion of successful outcomes in the testing set: all successful
# outcomes get predicted correctly, and all non-successful outcomes get predicted incorrectly.





##########################################################
# 4.3 Logistic Regression
##########################################################


# This section deploys the logistic regression model.
# See section 4.1 for a theoretical introduction to this model.





# We start by training the model on the basis of the training set.
# In order to do so, we use the train() function from the caret package, and specify the method as
# being “glm” (generalized linear model).

train_glm <- train(outcome_type ~ ., method = "glm", data = training_set)





# Then we apply the model to the testing set.

p_hat_glm <- predict(train_glm, newdata = testing_set, type = "prob")





# And finally we deploy a decision rule to assign a class to each probability value of p_hat_glm.
# A probability value above 0.5 will be assigned to “class 1” (success), while other probability
# values will be assigned to “class 0” (non-success).

# first we select only the second column of p_hat_glm
# which is the one giving the probability of belonging to class 1 (success)
p_hat_glm <- p_hat_glm %>%
  select(2)

# then we deploy the decision rule
y_hat_glm <- ifelse(p_hat_glm > 0.5, 1, 0) %>% factor





# Having done that, we can extract the classification accuracy of this model.
# We also add it to the table that will collect the accuracy score of each algorithm.

# first we extract the accuracy score
accuracy_glm <- confusionMatrix(y_hat_glm, testing_set$outcome_type)$overall[["Accuracy"]]
# accuracy_glm = 0.7021999

# then we store the accuracy score in a table and display this table
accuracy_scores <- bind_rows(accuracy_scores, data_frame(section = "4.3",
                                                         model = "logistic regression",
                                                         accuracy = accuracy_glm))
accuracy_scores





# We see that the model accuracy is approximately 70.22%.
# As a reminder, baseline accuracy is 63.80%. We can thus conclude that a simple logistic regression
# already brings some improvement to our predictions.





##########################################################
# 4.4 K-Nearest-Neighbors (KNN)
##########################################################


# This section deploys the k-nearest-neighbors model (knn).
# See section 4.1 for a theoretical introduction to this model.





# We start by training the model on the basis of the training set.
# In order to do so, we use the train() function from the caret package, and specify the method as
# being “knn”.
# This training process also involves the identification of the optimal value of the tuning parameter
# k. In other words, we explore which value of k yields the highest training accuracy. This tuning is
# performed on the basis of 10-fold cross-validation (as defined by the “control” parameter within
# the train() function).

# start by setting the seed to 3 (as cross-validation involves randomness)
set.seed(3, sample.kind = "Rounding") # if using R 3.5 or earlier, remove the sample.kind argument

# then opt for 10-fold cross-validation
control <- trainControl(method = "cv", number = 10, p = .9)

# finally, train the model and tune the parameter k by means of 10-fold cross-validation
train_knn <- train(outcome_type ~ ., method = "knn", data = training_set,
                   tuneGrid = data.frame(k = seq(1, 50, 2)), trControl = control)





# Now we can extract the optimal value of k. We also plot training accuracy against the different
# values of k in order to better visualize the outcome of the tuning process.

# extract the optimal value of k
best_k <- train_knn$bestTune # best_k = 15 (8th possible value of k in the selected range)

# plot the training accuracy against the different values of k
ggplot(train_knn, highlight = TRUE) +
  ggtitle("Tuning of the parameter k")





# This plot shows us that training accuracy increases significantly in the left part of the chart,
# with a peak at k = 15. This peak is then followed by a slow decline, with training accuracy
# gradually decreasing as k further increases.





# We can now apply the tuned model to the testing set.

y_hat_knn <- predict(train_knn, testing_set)





# Having done that, we can extract the classification accuracy of this model.
# We also display it in a table that will collect the accuracy score of each algorithm.

# first we extract the accuracy score
accuracy_knn <- confusionMatrix(y_hat_knn, testing_set$outcome_type)$overall[["Accuracy"]]
# accuracy_knn = 0.7227226	

# then we store the accuracy score in a table and display this table
accuracy_scores <- bind_rows(accuracy_scores, data_frame(section = "4.4",
                                                         model = "knn",
                                                         accuracy = accuracy_knn))
accuracy_scores





# We see that the model accuracy is approximately 72.27%.
# As a reminder, baseline accuracy is 63.80% and logistic regression has an accuracy of 70.22%.
# We can thus conclude that the implementation of a knn model brings some further improvement to
# our predictions.





##########################################################
# 4.5 Classification Tree
##########################################################


# This section deploys the classification tree model.
# See section 4.1 for a theoretical introduction to this model.





# We start by training the model on the basis of the training set.
# In order to do so, we use the train() function from the caret package, and specify the method as
# being “rpart”.
# This training process also involves the identification of the optimal value of the tuning parameter
# cp (“complexity parameter” used to control the size of the decision tree). In other words, we
# explore which value of cp yields the highest training accuracy. This tuning is performed on the
# basis of 10-fold cross-validation (as defined by the “control” parameter within the train()
# function).

# start by setting the seed to 4 (as cross-validation involves randomness)
set.seed(4, sample.kind = "Rounding") # if using R 3.5 or earlier, remove the sample.kind argument

# then opt for 10-fold cross-validation
control <- trainControl(method = "cv", number = 10, p = .9)

# finally, train the model and tune the parameter cp by means of 10-fold cross-validation
train_rpart <- train(outcome_type ~ ., method = "rpart", data = training_set,
                     tuneGrid = data.frame(cp = seq(0, 0.05, 0.002)), trControl = control)





# Now we can extract the optimal value of cp. We also plot the training accuracy associated with
# the different values of cp in order to better visualize the outcome of the tuning process.

# extract the optimal value of cp
best_cp <- train_rpart$bestTune # best_cp = 0.002 (2nd possible value of cp in the selected range)

# plot the training accuracy against the different values of cp
ggplot(train_rpart, highlight = TRUE) +
  ggtitle("Tuning of the parameter cp")





# This plot shows us that training accuracy already peaks at cp = 0.002. Accuracy then decreases
# again and hits a plateau between cp = 0.008 and cp = 0.04.





# We can now apply the tuned model to the testing set.

y_hat_rpart <- predict(train_rpart, testing_set)





# Having done that, we can extract the classification accuracy of this model.
# We also display it in a table that will collect the accuracy score of each algorithm.

# first we extract the accuracy score
accuracy_rpart <- confusionMatrix(y_hat_rpart, testing_set$outcome_type)$overall[["Accuracy"]]
# accuracy_rpart = 0.7349771	

# then we store the accuracy score in a table and display this table
accuracy_scores <- bind_rows(accuracy_scores, data_frame(section = "4.5",
                                                         model = "classification tree",
                                                         accuracy = accuracy_rpart))
accuracy_scores





# We see that the model accuracy is approximately 73.50%.
# As a reminder, the accuracy of logistic regression and knn is 70.22% and 72.27% respectively.
# We can thus conclude that the implementation of a classification tree model brings some further
# improvement to our predictions.





# As mentioned in section 4.1, classification trees have the advantage of being more “transparent”
# than logistic regression or knn in terms of the importance of individual variables (such as animal
# type or breed). Indeed, it is possible to plot our classification tree in order to find out which
# variables have been selected as splitting criteria in nodes.

# In order to do so, we use the rpart.plot() function from the eponymous package, as this allows us
# to create more aesthetic trees.

# In this regard, the main challenge encountered with our tree lies in the high number of nodes to
# be displayed. If one were to use default parameters of the rpart.plot() function, several text
# boxes (nodes) would be overlapping and the end result would not be legible. Consequently, we had
# to adjust function parameters in order to reduce overlapping, while making sure at the same time
# that font size (“cex” parameter) remained large enough for text boxes to be legible.

# The plot below balances these two conflicting objectives relatively well (box overlapping v. font
# size), as there is only one minor instance of overlapping boxes: the bottom-left nodes should
# read “sex_upon_intakeSpayed Female” and “intake_conditionNormal” respectively.

rpart.plot(train_rpart$finalModel,
           type = 5,
           extra = 0,
           fallen.leaves = TRUE,
           cex = 0.55,
           space = 1,
           yspace = 0.9,
           Fallen.yspace = 0.01,
           gap = 2)

# type = 5: show the split variable name in the interior nodes
# extra = 0: no extra information displayed at the nodes
# fallen.leaves = TRUE: position the leaf nodes at the bottom of the graph
# cex = 0.55: text size
# space = 1: horizontal space to the box border on each side of the node label text, in character widths
# yspace = 0.9: vertical space to the box border above and below the node label text, in character heights
# Fallen.yspace = 0.01: extra space for fallen leaves. Default .1, meaning allow 10% of the vertical space for the fallen leaves
# gap = 2: minimum horizontal gap between the boxes, in character widths





# Successful outcomes (1) are displayed as green leaves, while unsuccessful outcomes (0) are
# displayed in blue.

# We can see that the variable with the highest predictive power seems to be “animal type”,
# because the first node performs a split on the basis of whether or not an animal is a dog.
# The next two nodes are built on the basis of “sex upon intake” and “intake condition”,
# indicating that these variables also display a high predictive power.





##########################################################
# 4.6 Random Forest
##########################################################


# This section deploys the random forest model.
# See section 4.1 for a theoretical introduction to this model.





# We start by training the model on the basis of the training set.
# In order to do so, we use the train() function from the caret package, and specify the method
# as being “rf”.
# This training process also involves the identification of the optimal value of the tuning
# parameter mtry (number of variables randomly sampled as candidates at each split). In other
# words, we explore which value of mtry yields the highest training accuracy. This tuning is
# performed on the basis of 10-fold cross-validation (as defined by the “control” parameter
# within the train() function).

# In classification problems, the default value for mtry is the square root of p, where p is the
# number of predictors. However, there is a subtlety in that regard, as “animal_typeDog” and
# “animal_typeCat” are understood to be two different categorical variables when it comes to
# defining the value of p.

# This is something that will also be confirmed later when displaying the ranking of important
# variables by means of the varImp() function: according to varImp(), the value of p is 295 for
# the training set (reflecting inter alia the large number of breeds). The default value of mtry
# would therefore be sqrt(295), i.e. approximately 17.

# With this in mind, we perform cross-validation over the range of mtry values given by
# seq(1, 50, 2), so that we evaluate enough values around 17.

# start by setting the seed to 5 (as cross-validation involves randomness)
set.seed(5, sample.kind = "Rounding") # if using R 3.5 or earlier, remove the sample.kind argument

# then opt for 10-fold cross-validation
control <- trainControl(method = "cv", number = 10, p = .9)

# finally, train the model and tune the parameter mtry by means of 10-fold cross-validation
train_rf <- train(outcome_type ~ ., method = "rf", data = training_set,
                  tuneGrid = data.frame(mtry = seq(1, 50, 2)), ntree = 100, trControl = control)





# Now we can extract the optimal value of mtry. We also plot the training accuracy associated
# with the different values of mtry in order to better visualize the outcome of the tuning
# process.

# extract the optimal value of mtry
best_mtry <- train_rf$bestTune # best_mtry = 37 (19th possible value of mtry in the selected range)

# plot the training accuracy against the different values of mtry
ggplot(train_rf, highlight = TRUE) +
  ggtitle("Tuning of the parameter mtry")





# This plot shows us that training accuracy increases significantly in the left part of the chart,
# with a peak at mtry = 37. This peak is then followed by a very slow decline, with training
# accuracy only decreasing very marginally as mtry further increases.

y_hat_rf <- predict(train_rf, testing_set)





# Having done that, we can extract the classification accuracy of this model.
# We also display it in a table that will collect the accuracy score of each algorithm.

# first we extract the accuracy score
accuracy_rf <- confusionMatrix(y_hat_rf, testing_set$outcome_type)$overall[["Accuracy"]]
# accuracy_rf = 0.7513657	

# then we store the accuracy score in a table and display this table
accuracy_scores <- bind_rows(accuracy_scores, data_frame(section = "4.6", model =
                                                           "random forest",
                                                         accuracy = accuracy_rf))
accuracy_scores





# We see that the model accuracy is approximately 75.14%.
# As a reminder, the accuracy of logistic regression, knn and classification tree is 70.22%,# 
# 72.27% and 73.50% respectively. We can thus conclude that the implementation of a random forest
# model brings some further improvement to our predictions.





# As mentioned in section 4.1, random forests have the advantage of being more “transparent” than
# logistic regression or knn in terms of the importance of individual variables (such as animal
# type or breed). Indeed, it is possible to create a ranking table in order to find out which
# variables have been used most frequently as splitting criteria in tree nodes.

# In order to do so, we use the varImp() function from the caret package, as this allows us to
# extract information on the importance of individual variables, and to display this information
# in a ranking table.

# first extract information on the importance of individual variables
var_imp_rf <- varImp(train_rf)

# then display the 20 most important variables in a ranking table
var_imp_rf





# We can see that age upon intake is the variable that has been used most frequently as a
# splitting criterion in tree nodes. In fact, it has even been used in every tree of the random
# forest, as indicated by its score of 100%.

# While this observation can be surprising at first glance, one needs to be reminded that the
# varImp() function considers every factor be a categorical variable in itself, e.g.
# “animal_typeDog” and “animal_typeCat” are understood to be two different categorical variables.
# As the only non-categorical variable of the training set, age upon intake is not subject to this
# mechanism: varImp() considers age upon intake to be one single variable, and does not
# differentiate between “age_upon_intake_days1” and “age_upon_intake_days365” for instance.
# Consequently, it is normal that age upon intake is ranked as the most important variable,
# because it is the only variable that is not broken down into a collection of sub-variables by
# the varImp() function.

# If one looks beyond age upon intake, one can see that three categorical variables seem to be
# particularly important, as these are the only ones with a score above 20%:
# “sex_upon_intakeUnknown”, “animal_typeCat” and “animal_typeDog”. Interestingly, this ranking is
# similar to the one observed in the classification tree of section 4.5: the top node of the tree
# referred to animal type as well (dog v. no-dog), and “sex_upon_intakeUnknown” was one of the two
# splitting criteria used immediately after the top node.

# In this regard, the random forest model can be said to be relatively well in line with the
# findings of section 4.5, thereby confirming that animal type and sex upon intake seem to
# display a high level of predictive power.





##########################################################
# 4.7 Hold-Out Set
##########################################################


# In this section, our best-performing algorithm is tested once again on the basis of the hold-out
# set.

# As demonstrated in section 4.6, the random forest model is our best-performing algorithm, with
# an accuracy of 75.14% when applied to the testing set.

# We therefore deploy this model once again, this time on the basis of the hold-out set.

y_hat_rf_hold_out_set <- predict(train_rf, hold_out_set)





# Having done that, we can extract the classification accuracy of this model.
# We also display it in a table that will collect the accuracy score of each algorithm.

# first we extract the accuracy score
accuracy_rf_hold_out_set <- confusionMatrix(y_hat_rf_hold_out_set, hold_out_set$outcome_type)$overall[["Accuracy"]]
# accuracy_rf_hold_out_set = 0.8541058	

# then we store the accuracy score in a table and display this table
accuracy_scores <- bind_rows(accuracy_scores, data_frame(section = "4.7", model =
                                                           "random forest (hold-out set)",
                                                         accuracy = accuracy_rf_hold_out_set))
accuracy_scores





# We see that the model accuracy is approximately 85.41%.

# As a reminder, the accuracy of the same random forest model was only 75.14% when working on the
# basis of the testing set. We can thus conclude that the predictive power of this model displays
# non-negligible fluctuations across these two sets. This hints at the fact that the size of these
# sets may not be sufficient to get a clear picture of the real predictive power of this model
# – i.e. one would probably observe less fluctuations if these sets were larger.





##########################################################
# 5. Results
##########################################################


# Chapter 5 (Results) discusses the performance of the five machine learning models used in the
# previous chapter.





# Let us first display the recap table with all accuracy scores.

accuracy_scores





# Our first benchmark was the accuracy score of 63.80% obtained with the baseline model from
# section 4.2, where we predicted every outcome to be a success. This result simply corresponds
# to the proportion of successful outcomes in the testing set: all successful outcomes get
# predicted correctly, and all non-successful outcomes get predicted incorrectly.

# The next two sections (4.3 and 4.4) deployed basic classification algorithms, namely logistic
# regression and k-nearest neighbors (knn). Both models were able to bring some further
# improvement to our predictions, with accuracy rising to 70.22% and 72.27% respectively.

# The next two sections (4.5 and 4.6) focused on models that are more “transparent” in terms of
# the importance of individual variables – i.e. models that allow one to draw conclusions about
# the predictive power of each variable (such as animal type or breed). In this respect, we first
# deployed a classification tree model (section 4.5), followed by a random forest model (section
# 4.6). Accuracy rose to 73.50% and 75.14% respectively, and we were also able to identify some
# of the most important variables, such as animal type (dog v. non-dog) and sex upon intake
# (known v. unknown).

# The last section (4.7) applied our best-performing algorithm (i.e. random forest) to the
# hold-out set. As the accuracy score was much higher (85.41%), we concluded that the predictive
# power of this model displayed important fluctuations across the two sets (testing set v. 
# hold-out set). This hints at the fact that the size of these sets may not be sufficiently large
# in order to assess the real predictive power of our model.

# Overall, we can draw two main conclusions from this discussion of results.

# (1) The approach taken in sections 4.2 to 4.6 has shown satisfying results, as each section was
# able to bring some further improvements to our accuracy score – with the latter ranging from
# 63.80% (section 4.2, baseline model) to 75.14% (section 4.6, random forest).

# (2) Upon applying our best-performing model (random forest) to the hold-out set (section 4.7),
# we observed an important fluctuation in the accuracy score (75.14% v. 85.41%), indicating that
# larger sets would probably be needed in order to assess the real predictive power of our model.





##########################################################
# 6. Conclusion
##########################################################


# The aim of this report has been to present the various data analysis and machine learning tasks
# performed on the basis of the “Austin Animal Center Shelter Intakes and Outcomes” dataset, as
# part of the HarvardX curriculum in data science.

# After performing data cleaning (section 2.1) and data partition (section 2.2), we carried out 
# various data visualization tasks (chapter 3) in order to better understand the relationship
# between the outcome variable (success v. non-success) and each predictor variable. In this
# respect, the proportion of successful outcomes was shown to vary rather importantly across
# animal types and breeds, as well as intake conditions and intake types. On the contrary, the
# impact of intake months and intake weekdays did not appear to be significant.

# Having identified these patterns, we then attempted to deploy various machine learning models.
# As a benchmark, we used a baseline model that predicted every outcome to be a success (section
# 4.2). We gradually added layers of complexity to this baseline model, as the next four sections
# (4.3 to 4.6) went from basic classification algorithms (logistic regression and knn) to more 
# sophisticated models (classification tree and random forest).

# The best-performing algorithm was the random forest model, with an accuracy score of 75.14% on
# the basis of the testing set (compared to 63.80% for the baseline model). This model was then
# applied to the hold-out set in section 4.7, producing an accuracy score of 85.41%. As the 
# difference between the two scores was significant, we concluded that the size of these sets may
# not be sufficiently large in order to assess the real predictive power of our model.

# Let us end this report with a brief discussion of its limitations, as well as suggestions for
# future work. In this regard, two main points come to mind.

# First, one could get a clearer picture of the real predictive power of our models by working on
# a larger dataset – it can indeed be expected that the accuracy score would not fluctuate as
# much if the testing set and hold-out set were larger. Consequently, it may be of interest for
# some readers to attempt to find a larger dataset on animal shelters, and to assess whether the
# accuracy score displays a lower degree of fluctuation across the testing and hold-out sets.

# Second, the scope of this report is also limited by the instructions provided in the HarvardX
# grading rubric – namely the fact that only two machine learning algorithms need to be deployed
# in order to comply with these guidelines. While this report goes a bit further and deploys four
# models instead of two (logistic regression, knn, classification tree, random forest), it is
# clear that it nonetheless leaves a lot of room for the implementation of further models.
# Some readers may therefore be encouraged to develop more sophisticated models in order to bring
# some additional improvement to our accuracy score (e.g. by training a neural network).



